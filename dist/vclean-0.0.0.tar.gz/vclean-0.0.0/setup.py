from setuptools import setup, find_packages

setup(
    name='vClean',
    version="0.0.0",
    description="Identifying contamination from viral genomes",
    author='Ryota Wagatsuma',
    packages=find_packages(),
    license='MIT',
)
