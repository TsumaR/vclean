## vclean

inputを一つのvSAG, vMAGごとにする
